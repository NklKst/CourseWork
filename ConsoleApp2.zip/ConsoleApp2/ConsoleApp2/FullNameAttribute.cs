﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApp2
{
    [AttributeUsage(AttributeTargets.Property)]
    public class FullNameAttribute : Attribute
    {
        public string ErrorMessage { get; }

        public FullNameAttribute(string errorMessage = "Некоректне значення")
        {
            ErrorMessage = errorMessage;
        }

        public bool IsValid(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;

            // тільки літери + мінімум 2 символи
            return Regex.IsMatch(value, @"^[А-Яа-яІіЇїЄєA-Za-z]{2,}$");
        }
    }
}
