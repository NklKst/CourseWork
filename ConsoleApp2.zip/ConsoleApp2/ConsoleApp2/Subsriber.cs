﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace ConsoleApp2
{
    public abstract class Subsriber
    {


        private string surname = string.Empty;
        private string name = string.Empty;
        private string middlename = string.Empty;
        private string callId = string.Empty;

        [FullName("Прізвище обов'язкове і тільки літери")]
        public string Surname { get => surname; set => surname = value; }        
        [FullName("Ім'я обов'язкове і тільки літери")]
        public string Name { get => name; set => name = value; }
        [FullName("По-батькові обов'язкове і тільки літери")]
        public string Middlename { get => middlename; set => middlename = value; }        
        public string CallId { get => callId; set => callId = value; }

        

        public Subsriber() { Surname = string.Empty; Name = string.Empty; Middlename = string.Empty; CallId = string.Empty; }

        public abstract void DisplayInfo();
        public abstract void GetDetails();                
    }
}
