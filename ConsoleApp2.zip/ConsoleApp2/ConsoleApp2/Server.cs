﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.Json;

namespace ConsoleApp2
{
    public class Server
    {
        private readonly HashTable hashTable;
        private readonly List<Teacher> teachers;
        private readonly JsonSerializator serializator;
        private readonly HttpListener listener;
        private const string staffPath = "subscribers.json";
        private const string teacherPath = "teachers.json";
        private const string baseUrl = "http://localhost:5000/";

        public Server()
        {
            hashTable = new HashTable();
            teachers = new List<Teacher>();
            serializator = new JsonSerializator();
            listener = new HttpListener();
            listener.Prefixes.Add(baseUrl);
        }

        // ── Запуск у фоновому потоці ─────────────────────────────────────────
        public void StartBackground()
        {
            LoadFromFiles();
            listener.Start();
            var thread = new Thread(Loop) { IsBackground = true };
            thread.Start();
            Console.WriteLine("[Server] Запущено на " + baseUrl);
        }

        private void LoadFromFiles()
        {
            var s = serializator.Deserialize<List<Staff>>(staffPath);
            if (s != null) foreach (var item in s) hashTable.AddSub(item);

            var t = serializator.Deserialize<List<Teacher>>(teacherPath);
            if (t != null) teachers.AddRange(t);
        }

        // ── Головний цикл обробки запитів ────────────────────────────────────
        private void Loop()
        {
            while (listener.IsListening)
            {
                try
                {
                    var ctx = listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => Handle(ctx));
                }
                catch { }
            }
        }

        private void Handle(HttpListenerContext ctx)
        {
            var req = ctx.Request;
            var res = ctx.Response;
            string path = req.Url?.AbsolutePath ?? "";
            string method = req.HttpMethod;

            try
            {
                string body = "";
                if (req.HasEntityBody)
                    using (var sr = new StreamReader(req.InputStream, req.ContentEncoding))
                        body = sr.ReadToEnd();

                var opts = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    WriteIndented = true
                };

                // ── Staff endpoints ──────────────────────────────────────────
                if (path == "/staff" && method == "GET")
                {
                    string? q = req.QueryString["q"];
                    string? pos = req.QueryString["position"];
                    string? letter = req.QueryString["letter"];

                    List<Staff> result;
                    if (!string.IsNullOrEmpty(q))
                        result = hashTable.SearchByName(q);
                    else if (!string.IsNullOrEmpty(pos))
                        result = hashTable.SearchByPosition(pos);
                    else if (!string.IsNullOrEmpty(letter))
                        result = hashTable.SortBySurname()
                            .Where(s => s.Surname.StartsWith(letter,
                                StringComparison.OrdinalIgnoreCase)).ToList();
                    else
                        result = hashTable.SortBySurname();

                    Respond(res, 200, JsonSerializer.Serialize(result, opts));
                }
                else if (path == "/staff" && method == "POST")
                {
                    var staff = JsonSerializer.Deserialize<Staff>(body, opts);
                    if (staff != null) hashTable.AddSub(staff);
                    Respond(res, 200, "{\"status\":\"ok\"}");
                }
                else if (path == "/staff/find" && method == "GET")
                {
                    string? phone = req.QueryString["phone"];
                    var sub = phone != null ? hashTable.Find(phone) : null;
                    if (sub != null)
                        Respond(res, 200, JsonSerializer.Serialize(sub, opts));
                    else
                        Respond(res, 404, "{\"error\":\"not found\"}");
                }
                else if (path == "/staff" && method == "DELETE")
                {
                    string? phone = req.QueryString["phone"];
                    if (phone != null) hashTable.Remove(phone);
                    Respond(res, 200, "{\"status\":\"ok\"}");
                }

                // ── Teacher endpoints ────────────────────────────────────────
                else if (path == "/teachers" && method == "GET")
                {
                    string? q = req.QueryString["q"];
                    List<Teacher> result = string.IsNullOrEmpty(q)
                        ? teachers.OrderBy(t => t.Surname).ThenBy(t => t.Name).ToList()
                        : teachers.Where(t =>
                            t.Surname.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                            t.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                            t.Department.Contains(q, StringComparison.OrdinalIgnoreCase))
                          .OrderBy(t => t.Surname).ToList();

                    Respond(res, 200, JsonSerializer.Serialize(result, opts));
                }
                else if (path == "/teachers" && method == "POST")
                {
                    var teacher = JsonSerializer.Deserialize<Teacher>(body, opts);
                    if (teacher != null) teachers.Add(teacher);
                    Respond(res, 200, "{\"status\":\"ok\"}");
                }

                // ── Save endpoint ────────────────────────────────────────────
                else if (path == "/save" && method == "POST")
                {
                    serializator.Serialize(hashTable.GetAll(), staffPath);
                    serializator.Serialize(teachers, teacherPath);
                    Respond(res, 200, "{\"status\":\"saved\"}");
                }
                else
                {
                    Respond(res, 404, "{\"error\":\"unknown route\"}");
                }
            }
            catch (Exception ex)
            {
                Respond(res, 500, $"{{\"error\":\"{ex.Message}\"}}");
            }
        }

        private static void Respond(HttpListenerResponse res, int code, string json)
        {
            res.StatusCode = code;
            res.ContentType = "application/json; charset=utf-8";
            byte[] buf = Encoding.UTF8.GetBytes(json);
            res.ContentLength64 = buf.Length;
            res.OutputStream.Write(buf, 0, buf.Length);
            res.OutputStream.Close();
        }
    }
}
