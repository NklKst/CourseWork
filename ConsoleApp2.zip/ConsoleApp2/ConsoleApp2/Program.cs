﻿using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Transactions;
using System.Runtime.InteropServices;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = System.Text.Encoding.UTF8;
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Запускаємо HTTP-сервер у фоновому потоці
            var server = new Server();
            server.StartBackground();

            // Даємо серверу час піднятися
            Thread.Sleep(500);

            // Клієнт спілкується з сервером через HTTP
            var client = new Client();

            bool isRunning = true;

            while (isRunning)
            {
                Console.Clear();
                Console.WriteLine("╔══════════════════════════════╗");
                Console.WriteLine("║       Облік АТС ВВНЗ         ║");
                Console.WriteLine("╚══════════════════════════════╝\n");
                Console.WriteLine(" --- Працівники (Staff) ---");
                Console.WriteLine("  1. Додати працівника");
                Console.WriteLine("  2. Знайти за ідентифікатором абонента");
                Console.WriteLine("  3. Показати всіх (за алфавітом)");
                Console.WriteLine("  4. Видалити працівника");
                Console.WriteLine("  5. Пошук за іменем / прізвищем");
                Console.WriteLine("  6. Пошук за посадою");
                Console.WriteLine("\n --- Викладачі (Teacher) ---");
                Console.WriteLine("  7. Додати викладача");
                Console.WriteLine("  8. Показати всіх викладачів");
                Console.WriteLine("  9. Пошук викладача");
                Console.WriteLine("\n --- Система ---");
                Console.WriteLine("  10. Зберегти дані");
                Console.WriteLine("   0. Вийти\n");
                Console.Write("  Оберіть дію: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Невірний вибір.");
                    Pause();
                    continue;
                }

                Console.Clear();

                switch (choice)
                {
                    // ── Працівники ────────────────────────────────────────────
                    case 1:
                        Console.WriteLine("=== Додати працівника ===\n");
                        var staff = new Staff();
                        staff.GetDetails();
                        if (client.AddStaff(staff))
                            Console.WriteLine("\nПрацівника успішно додано.");
                        else
                            Console.WriteLine("\nПомилка при додаванні.");
                        Pause();
                        break;

                    case 2:
                        Console.WriteLine("=== Пошук за ідентифікатором абонента ===\n");
                        Console.Write("Номер телефону: ");
                        string phone = Console.ReadLine() ?? "";
                        var found = client.FindStaff(phone);
                        Console.WriteLine();
                        if (found != null) { Console.WriteLine("--- Знайдено ---"); found.DisplayInfo(); }
                        else Console.WriteLine("Абонента не знайдено.");
                        Pause();
                        break;

                    case 3:
                        Console.WriteLine("=== Всі працівники (за алфавітом) ===\n");
                        // Фільтрація автоматична — сервер повертає вже відсортований список
                        PrintStaff(client.GetAllStaff());
                        Pause();
                        break;

                    case 4:
                        Console.WriteLine("=== Видалити працівника ===\n");
                        Console.Write("Ідентифікатор абонента: ");
                        string delPhone = Console.ReadLine() ?? "";
                        var toDelete = client.FindStaff(delPhone);
                        Console.WriteLine();
                        if (toDelete == null)
                        {
                            Console.WriteLine("Абонента не знайдено.");
                        }
                        else
                        {
                            toDelete.DisplayInfo();
                            Console.Write("\nПідтвердити видалення? (1=Так / 0=Ні): ");
                            if (Console.ReadLine()?.Trim() == "1")
                            {
                                if (client.DeleteStaff(delPhone))
                                    Console.WriteLine("Абонента видалено.");
                            }
                            else Console.WriteLine("Скасовано.");
                        }
                        Pause();
                        break;

                    case 5:
                        Console.WriteLine("=== Пошук за іменем / прізвищем ===\n");
                        Console.Write("Запит: ");
                        string nameQ = Console.ReadLine() ?? "";
                        Console.WriteLine();
                        var byName = client.SearchStaffByName(nameQ);
                        Console.WriteLine($"Результати для \"{nameQ}\":\n");
                        PrintStaff(byName);
                        Pause();
                        break;

                    case 6:
                        Console.WriteLine("=== Пошук за посадою ===\n");
                        Console.Write("Посада (або частина): ");
                        string posQ = Console.ReadLine() ?? "";
                        Console.WriteLine();
                        var byPos = client.SearchStaffByPosition(posQ);
                        Console.WriteLine($"Результати для \"{posQ}\":\n");
                        PrintStaff(byPos);
                        Pause();
                        break;

                    // ── Викладачі ─────────────────────────────────────────────
                    case 7:
                        Console.WriteLine("=== Додати викладача ===\n");
                        var teacher = new Teacher();
                        teacher.GetDetails();
                        if (client.AddTeacher(teacher))
                            Console.WriteLine("\nВикладача успішно додано.");
                        else
                            Console.WriteLine("\nПомилка при додаванні.");
                        Pause();
                        break;

                    case 8:
                        Console.WriteLine("=== Всі викладачі (за алфавітом) ===\n");
                        PrintTeachers(client.GetAllTeachers());
                        Pause();
                        break;

                    case 9:
                        Console.WriteLine("=== Пошук викладача ===\n");
                        Console.Write("Ім'я, прізвище або кафедра: ");
                        string tQ = Console.ReadLine() ?? "";
                        Console.WriteLine();
                        var teachers = client.SearchTeachers(tQ);
                        Console.WriteLine($"Результати для \"{tQ}\":\n");
                        PrintTeachers(teachers);
                        Pause();
                        break;

                    // ── Система ───────────────────────────────────────────────
                    case 10:
                        if (client.Save())
                            Console.WriteLine("Дані збережено.");
                        else
                            Console.WriteLine("Помилка збереження.");
                        Pause();
                        break;

                    case 0:
                        client.Save();
                        Console.WriteLine("До побачення!");
                        isRunning = false;
                        break;

                    default:
                        Console.WriteLine("Невірний вибір.");
                        Pause();
                        break;
                }
            }
        }

        static void PrintStaff(List<Staff> list)
        {
            if (list.Count == 0) { Console.WriteLine("  (порожньо)"); return; }
            foreach (var s in list) { s.DisplayInfo(); Console.WriteLine("  --------------------"); }
            Console.WriteLine($"\n  Всього: {list.Count}");
        }

        static void PrintTeachers(List<Teacher> list)
        {
            if (list.Count == 0) { Console.WriteLine("  (порожньо)"); return; }
            foreach (var t in list) { t.DisplayInfo(); Console.WriteLine("  --------------------"); }
            Console.WriteLine($"\n  Всього: {list.Count}");
        }

        static void Pause()
        {
            Console.Write("\nНатисніть будь-яку клавішу...");
            Console.ReadKey();
        }
    }
}
