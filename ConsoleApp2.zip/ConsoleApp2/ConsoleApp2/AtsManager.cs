﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class AtsManager
    {
        private readonly HashTable hashTable;
        private readonly JsonSerializator jsonSerializator;
        private const string filePath = "subscribers.json";

        public AtsManager()
        {
            hashTable = new HashTable();
            jsonSerializator = new JsonSerializator();
        }

        public void LoadSubscribers()
        {
            var subscribers = jsonSerializator.Deserialize<List<Staff>>(filePath);
            if (subscribers != null)
            {
                foreach (var sub in subscribers)
                {
                    hashTable.AddSub(sub);
                }
                Console.WriteLine("Дані успішно завантажено!");
            }
            else
            {
                Console.WriteLine("Файл порожній або не знайдено.");
            }
        }

        public void SaveSubscribers()
        {
            var dataToSave = hashTable.GetAll();
            jsonSerializator.Serialize(dataToSave, filePath);
        }

        public HashTable Table => hashTable;
    }
}
