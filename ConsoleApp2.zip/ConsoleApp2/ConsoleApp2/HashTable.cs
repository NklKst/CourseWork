﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Text.Json;
using System.IO;



namespace ConsoleApp2
{
    public class HashTable
    {
        private const int size = 31;
        private readonly LinkedList<Staff>[] table;

        public HashTable()
        {
            table = new LinkedList<Staff>[size];
        }

        private int GetIndex(string phoneNum)
        {
            if (string.IsNullOrEmpty(phoneNum)) return 0;
            uint hash = 0;
            foreach (char c in phoneNum) hash = (hash * 31) + c;
            return (int)(hash % size);
        }
        
        public void AddSub(Staff sub)
        {
            if (sub == null || string.IsNullOrEmpty(sub.CallId)) return;

            int index = GetIndex(sub.CallId);

            if (table[index] == null)
                table[index] = new LinkedList<Staff>();

            // Перевіряємо, чи вже є такий номер (щоб не було дублікатів)
            var existing = table[index].FirstOrDefault(s => s.CallId == sub.CallId);
            if (existing != null) table[index].Remove(existing);

            table[index].AddLast(sub);
        }

        public Staff? Find(string phoneNum)
        {
            int index = GetIndex(phoneNum);
            return table[index]?.FirstOrDefault(s => s.CallId == phoneNum);
        }

        public List<Staff> GetAll()
        {
            List<Staff> result = new List<Staff>();
            foreach (var bucket in table)
            {
                if (bucket != null) result.AddRange(bucket);
            }
            return result;
        }

        public void ShowOne(string phoneNum)
        {
            var sub = Find(phoneNum);
            if (sub != null)
            {
                Console.WriteLine("\n--- Абонента знайдено ---");
                sub.DisplayInfo();
            }
            else
            {
                Console.WriteLine("Помилка: Абонента з таким номером не існує.");
            }
        }

        public void Remove(string phoneNum)
        {
            int index = GetIndex(phoneNum);
            var sub = table[index]?.FirstOrDefault(s => s.CallId == phoneNum);
            if (sub != null) table[index]!.Remove(sub);
        }

        public void Clear()
        {
            Array.Clear(table, 0, table.Length);
        }

        // Сортування за прізвищем (алфавіт)
        public List<Staff> SortBySurname()
        {
            return GetAll()
                .OrderBy(s => s.Surname, StringComparer.CurrentCulture)
                .ThenBy(s => s.Name, StringComparer.CurrentCulture)
                .ToList();
        }

        // Пошук за ім'ям або прізвищем
        public List<Staff> SearchByName(string query)
        {
            string q = query.Trim().ToLower();
            return GetAll()
                .Where(s =>
                    s.Surname.ToLower().Contains(q) ||
                    s.Name.ToLower().Contains(q) ||
                    s.Middlename.ToLower().Contains(q))
                .OrderBy(s => s.Surname, StringComparer.CurrentCulture)
                .ToList();
        }

        // Пошук за посадою
        public List<Staff> SearchByPosition(string query)
        {
            string q = query.Trim().ToLower();
            return GetAll()
                .Where(s => s is Staff st && st.Position.ToLower().Contains(q))
                .Cast<Staff>()
                .OrderBy(s => s.Surname, StringComparer.CurrentCulture)
                .ToList();
        }
    }
}

