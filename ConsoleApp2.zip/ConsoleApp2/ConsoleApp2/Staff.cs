﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Staff : Subsriber
    {
        private string position = string.Empty;

        public string Position { get => position; set => position = value; }        

        public override void GetDetails()
        {
            Console.WriteLine("Введіть інформацію про працівника.");
            Console.Write("Прізвище: ");
            Surname = Console.ReadLine() ?? string.Empty;
            Console.Write("Ім'я: ");
            Name = Console.ReadLine() ?? string.Empty;
            Console.Write("По-батькові: ");
            Middlename = Console.ReadLine() ?? string.Empty;
            Console.WriteLine("Ідентифікатор абоненту: ");
            CallId = Console.ReadLine() ?? string.Empty;
            Console.Write("Посада: ");
            Position = Console.ReadLine() ?? string.Empty;
        }

        public override void DisplayInfo()
        {
            Console.WriteLine($"Абонент: {Surname} {Name} {Middlename}, Посада: {Position}, Номер телефону: {CallId}"); 
        }

        public override string ToString()
        {
            return $"Працівник: {Surname} {Name}, Номер телефону: {CallId}, Посада: {Position}";
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override bool Equals(object? obj)
        {
            if (obj is Staff other)
            {
                return this.CallId == other.CallId;
            }
            return false;
        }
        
        
    }
}
