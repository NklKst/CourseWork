﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace ConsoleApp2
{
    public class Validator
    {
        public static List<string> Validate(object obj)
        {
            List<string> errors = new List<string>();

            var properties = obj.GetType().GetProperties();

            foreach (var prop in properties)
            {
                var value = prop.GetValue(obj);

                var fullNameAttr = prop.GetCustomAttribute<FullNameAttribute>();
                if (fullNameAttr != null)
                {
                    var strValue = value?.ToString() ?? "";

                    if (!fullNameAttr.IsValid(strValue))
                    {
                        errors.Add($"{prop.Name}: {fullNameAttr.ErrorMessage}");
                    }
                }
            }

            return errors;
        }

    }
}
