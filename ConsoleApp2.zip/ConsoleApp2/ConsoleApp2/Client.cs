﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace ConsoleApp2
{
    public class Client
    {
        private readonly HttpClient http;
        private const string base_url = "http://localhost:5000";
        private static readonly JsonSerializerOptions opts = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            WriteIndented = true
        };

        public Client()
        {
            http = new HttpClient();
        }

        // ── Допоміжні методи ─────────────────────────────────────────────────
        private T? Get<T>(string url)
        {
            try
            {
                var resp = http.GetAsync(url).Result;
                string json = resp.Content.ReadAsStringAsync().Result;
                if (!resp.IsSuccessStatusCode) return default;
                return JsonSerializer.Deserialize<T>(json, opts);
            }
            catch { Console.WriteLine("[Client] Помилка зв'язку з сервером."); return default; }
        }

        private bool Post(string url, object data)
        {
            try
            {
                string json = JsonSerializer.Serialize(data, opts);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var resp = http.PostAsync(url, content).Result;
                return resp.IsSuccessStatusCode;
            }
            catch { Console.WriteLine("[Client] Помилка зв'язку з сервером."); return false; }
        }

        private bool Delete(string url)
        {
            try
            {
                var resp = http.DeleteAsync(url).Result;
                return resp.IsSuccessStatusCode;
            }
            catch { Console.WriteLine("[Client] Помилка зв'язку з сервером."); return false; }
        }

        // ── Staff ─────────────────────────────────────────────────────────────
        public List<Staff> GetAllStaff()
        {
            Console.WriteLine("[Client → Server] GET /staff");
            return Get<List<Staff>>($"{base_url}/staff") ?? new List<Staff>();
        }

        public List<Staff> SearchStaffByName(string q)
        {
            Console.WriteLine($"[Client → Server] GET /staff?q={q}");
            return Get<List<Staff>>($"{base_url}/staff?q={Uri.EscapeDataString(q)}") ?? new List<Staff>();
        }

        public List<Staff> SearchStaffByPosition(string pos)
        {
            Console.WriteLine($"[Client → Server] GET /staff?position={pos}");
            return Get<List<Staff>>($"{base_url}/staff?position={Uri.EscapeDataString(pos)}") ?? new List<Staff>();
        }

        public Staff? FindStaff(string phone)
        {
            Console.WriteLine($"[Client → Server] GET /staff/find?phone={phone}");
            return Get<Staff>($"{base_url}/staff/find?phone={Uri.EscapeDataString(phone)}");
        }

        public bool AddStaff(Staff s)
        {
            Console.WriteLine("[Client → Server] POST /staff");
            return Post($"{base_url}/staff", s);
        }

        public bool DeleteStaff(string phone)
        {
            Console.WriteLine($"[Client → Server] DELETE /staff?phone={phone}");
            return Delete($"{base_url}/staff?phone={Uri.EscapeDataString(phone)}");
        }

        // ── Teacher ───────────────────────────────────────────────────────────
        public List<Teacher> GetAllTeachers()
        {
            Console.WriteLine("[Client → Server] GET /teachers");
            return Get<List<Teacher>>($"{base_url}/teachers") ?? new List<Teacher>();
        }

        public List<Teacher> SearchTeachers(string q)
        {
            Console.WriteLine($"[Client → Server] GET /teachers?q={q}");
            return Get<List<Teacher>>($"{base_url}/teachers?q={Uri.EscapeDataString(q)}") ?? new List<Teacher>();
        }

        public bool AddTeacher(Teacher t)
        {
            Console.WriteLine("[Client → Server] POST /teachers");
            return Post($"{base_url}/teachers", t);
        }

        // ── Save ──────────────────────────────────────────────────────────────
        public bool Save()
        {
            Console.WriteLine("[Client → Server] POST /save");
            return Post($"{base_url}/save", new { });
        }
    }
}
