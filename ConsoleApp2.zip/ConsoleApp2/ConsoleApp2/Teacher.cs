﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Teacher : Subsriber
    {
        private string department = string.Empty;
        private string degree = string.Empty;

        public string Department { get => department; set => department = value; }
        public string Degree { get => degree; set => degree = value; }

        public override void GetDetails()
        {
            Console.WriteLine("Введіть інформацію про викладача.");
            Console.Write("Прізвище: ");
            Surname = Console.ReadLine() ?? string.Empty;
            Console.Write("Ім'я: ");
            Name = Console.ReadLine() ?? string.Empty;
            Console.Write("По-батькові: ");
            Middlename = Console.ReadLine() ?? string.Empty;
            Console.Write("Номер телефону: ");
            CallId = Console.ReadLine() ?? string.Empty;
            Console.Write("Кафедра: ");
            Department = Console.ReadLine() ?? string.Empty;
            Console.Write("Науковий ступінь: ");
            Degree = Console.ReadLine() ?? string.Empty;
        }

        public override void DisplayInfo()
        {
            Console.WriteLine($"Викладач: {Surname} {Name} {Middlename}, Кафедра: {Department}, Ступінь: {Degree}, Тел.: {CallId}");
        }

        public override string ToString()
        {
            return $"Викладач: {Surname} {Name}, Тел.: {CallId}, Кафедра: {Department}";
        }

        public override int GetHashCode() => base.GetHashCode();

        public override bool Equals(object? obj)
        {
            if (obj is Teacher other)
                return this.CallId == other.CallId  ;
            return false;
        }
    }
}
