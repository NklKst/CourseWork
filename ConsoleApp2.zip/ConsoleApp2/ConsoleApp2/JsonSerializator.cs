﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Text.Encodings.Web;

namespace ConsoleApp2
{
    public class JsonSerializator
    {
        private readonly JsonSerializerOptions options;

        public JsonSerializator()
        {
            options = new JsonSerializerOptions
            {
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                WriteIndented = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
                PropertyNameCaseInsensitive = true
            };
        }

        public void Serialize<T>(T data, string filePath)
        {
            try
            {
                string json = JsonSerializer.Serialize(data, options);
                File.WriteAllText(filePath, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка серіалізації: {ex.Message}");
            }
        }

        public T? Deserialize<T>(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    return default;

                string json = File.ReadAllText(filePath);

                if (string.IsNullOrWhiteSpace(json))
                    return default;

                return JsonSerializer.Deserialize<T>(json, options);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка десеріалізації: {ex.Message}");
                return default;
            }
        }
    }
}
